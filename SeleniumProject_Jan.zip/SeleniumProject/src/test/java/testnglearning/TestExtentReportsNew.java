package testnglearning;

import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;

import extentlisteners.ExtentListeners;

public class TestExtentReportsNew {

	
	@Test
	public void doLogin() {
		
		ExtentListeners.test.info("Entering username");
		ExtentListeners.test.info("Entering password");
	}
	
	@Test
	public void doUserReg() {
		
		ExtentListeners.test.info("Entering firstName");
		ExtentListeners.test.info("Entering lastName");
		Assert.fail("User reg test failed");
		
	}
	
	@Test
	public void isSkip() {
		
		ExtentListeners.test.info("Verifying image");
		throw new SkipException("Skipping the test case");
	}
	
	
}
