package testnglearning;

import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.SkipException;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.Markup;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;

public class TestExtentReports {
	
	
	
	public ExtentSparkReporter htmlReporter; //Create HTML File
	public ExtentReports extent; //Add config, system, test cases
	public ExtentTest test; //pass,fail,skip etc
	
	
	
	@BeforeTest
	public void setReport() {
		
		htmlReporter = new ExtentSparkReporter("./reports/extent.html");
		htmlReporter.config().setEncoding("utf-8");
		htmlReporter.config().setDocumentTitle("W2A Automation Reports");
		htmlReporter.config().setReportName("Automation Test Results");
		htmlReporter.config().setTheme(Theme.STANDARD);
		
		extent = new ExtentReports();
		extent.attachReporter(htmlReporter);
		
		extent.setSystemInfo("Automation Tester", "Rahul Arora");
		extent.setSystemInfo("Organization", "Way2Automation");
		extent.setSystemInfo("Build No", "1234");
		
	}
	
	@Test
	public void doLogin() {
		
		test = extent.createTest("Login Test");
		test.log(Status.INFO,"Entering username");
		test.info("Entering Password");
		test.info("Clicking on the submit button");
		Assert.fail("Login test failed");
		
	}
	
	
	
	@Test
	public void doUserReg() {
		
		test = extent.createTest("User Reg Test");
		test.log(Status.INFO,"Entering username");
		test.info("Entering Password");
	
	}
	
	
	@Test
	public void doSkip() {
		
		test = extent.createTest("Skip Test");
		test.log(Status.INFO,"Entering username");
		
		throw new SkipException("Skipping the test case");
		
	}
	
	
	@AfterMethod
	public void updateResults(ITestResult result) {
		
		
		if(result.getStatus() == ITestResult.SUCCESS) {
			
			test.log(Status.PASS,"Test case pass");
			
			Markup m = MarkupHelper.createLabel(result.getMethod().getMethodName()+" - PASS", ExtentColor.GREEN);
			test.pass(m);
			
		}else if(result.getStatus() == ITestResult.FAILURE) {
			
			test.log(Status.FAIL,"Test case failed");
			Markup m = MarkupHelper.createLabel(result.getMethod().getMethodName()+" - FAILED", ExtentColor.RED);
			test.fail(m);
			
			
		}else if(result.getStatus() == ITestResult.SKIP) {
			
			test.log(Status.SKIP,"Test case Skipped");
			Markup m = MarkupHelper.createLabel(result.getMethod().getMethodName()+" - SKIPPED", ExtentColor.AMBER);
			test.skip(m);
			
			
		}
		
	}
	
	
	
	
	@AfterTest
	public void endReport() {
		
		extent.flush();
	}
	
	

}
