package testnglearning;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import utilities.ExcelReader;

public class TestParameterization {
	
	
	private WebDriver driver;

	
	@BeforeMethod
	public void launchBrowser() {
		
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
	
		driver.get("http://gmail.com");
	}
	
	
	@AfterMethod
	public void quit() {
		
		driver.quit();
		
	}
	
	
	
	@Test(dataProvider = "dp")
	public void loginTest(String username, String password) {
		
		//driver.findElement - enter username as trainer@way2automation.com
		//driver.findElement - enter username as asdfsdfsfd
		//click submit button
		
		driver.findElement(By.id("identifierId")).sendKeys(username);
		driver.findElement(By.xpath("//*[@id=\"identifierNext\"]/div/button/span")).click();
		driver.findElement(By.xpath("//*[@id=\"password\"]/div[1]/div/div[1]/input")).sendKeys(password);
	}
	
	
	@DataProvider(name = "dp")
	public Object[][] getData() {
		
		ExcelReader excel = new ExcelReader("./src/test/resources/excel/testdata.xlsx");
		
		String sheetName = "LoginTest";
		
		int rowNum = excel.getRowCount(sheetName);
		int colNum = excel.getColumnCount(sheetName);
		
		System.out.println("Data from excel : "+excel.getCellData(sheetName, 0, 2));
		
		System.out.println("Total rows are : "+rowNum+"  Total cols are : "+colNum);
		
		
		Object[][] data = new Object[rowNum-1][colNum];
		
		/*
		data[0][0] = excel.getCellData(sheetName, 0, 2);
		data[0][1] = excel.getCellData(sheetName, 1, 2);
		
		
		data[1][0] = excel.getCellData(sheetName, 0, 3);
		data[1][1] = excel.getCellData(sheetName, 1, 3);
		
		*/
		
		
		
		for(int rows=2;rows<=rowNum; rows++ ) {
			
			
			for(int cols=0; cols<colNum; cols++) {
				
				//data[1][0] = excel.getCellData(sheetName, 0, 3);
				data[rows-2][cols] = excel.getCellData(sheetName, cols, rows);
			}
			
		}
	
		
		
		return data;
		
	}
	
	
	
	
	
	
	
	
	
}
