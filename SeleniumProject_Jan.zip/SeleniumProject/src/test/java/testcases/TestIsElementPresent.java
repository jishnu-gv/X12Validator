package testcases;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestIsElementPresent {

	public static WebDriver driver;

	public static boolean isElementPresent(By by) {
		try {
			driver.findElement(by);
			return true;
		} catch (Throwable t) {

			return false;
		}
	}

	public static void main(String[] args) {


		driver = new ChromeDriver();
		driver.get("http://gmail.com");
		
		System.out.println(isElementPresent(By.id("identifierId")));
		
		
		
		

	}

}
