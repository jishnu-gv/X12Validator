package testcases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestFBLogin {

	public static void main(String[] args) {


		try {

		WebDriver driver = new ChromeDriver();
		driver.get("https://www.facebook.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		
		driver.findElement(By.xpath("//*[@id='email']")).sendKeys("asdfsdf");
		driver.findElement(By.xpath("//*[@id='pass']")).sendKeys("asdfsdf");
		                             //*[@id="u_0_5_Zg"]
		driver.findElement(By.xpath("//*[starts-with(@id,\"u_0_5\")]")).click();
		
		
		
		
		for(int i=1; i<=4; i++) {
			
			
			driver.findElement(By.xpath("//div[4]/input["+i+"]")).click();
		}
		
		
		
		}catch(Throwable t) {
			
			System.out.println(t.getMessage());
			t.printStackTrace();
		}
		
	
		
	

	}

}
