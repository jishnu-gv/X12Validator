package testcases;

import java.time.Duration;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestTabsAndPopups {

	public static void main(String[] args) {


		WebDriver driver = new ChromeDriver();
		driver.get("https://sso.teachable.com/secure/673/identity/sign_up/email");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		
		System.out.println("-----Printing window ids from the first window-----");
		
		
		Set<String> winids = driver.getWindowHandles();
		Iterator<String> iterator = winids.iterator();
		
		String first_window = iterator.next();
		System.out.println(first_window);
		
		
		
		driver.findElement(By.linkText("Privacy Policy")).click();
		
		System.out.println("-----Printing window ids from the Second window-----");
		
	
		
		winids = driver.getWindowHandles();
		iterator = winids.iterator();
		
		System.out.println(iterator.next()); 
		String second_window = iterator.next();
		System.out.println(second_window);
		
		driver.switchTo().window(second_window);

		driver.findElement(By.xpath("//*[@id=\"header-sign-up-btn\"]")).click();
		
		
		driver.findElement(By.id("user_name")).sendKeys("Rahul Arora");
		/*
		driver.close();
		driver.switchTo().window(first_window);
		driver.close();
		*/
		driver.quit();

	}

}
