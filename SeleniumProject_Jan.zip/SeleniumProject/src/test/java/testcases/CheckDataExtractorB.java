package testcases;

import java.io.File;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;

public class CheckDataExtractorB {

    public static void main(String[] args) throws IOException {
        String pdfFilePath = "D:\\Ramesh-Personal\\Selenium\\blank-check-template-3.pdf";
        File file = new File(pdfFilePath);
        PDDocument document = PDDocument.load(file);

        PDFTextStripper pdfTextStripper = new PDFTextStripper();
        String textContent = pdfTextStripper.getText(document);

        System.out.println(textContent);

        // Close the document
        document.close();

        extractCheckNumbersAndDates(textContent);
        extractPayeeAndAmount(textContent);
    }

    public static void extractCheckNumbersAndDates(String textContent) {
        Pattern checkNumberPattern = Pattern.compile("_{30,} (\\d{4,})");
        Pattern datePattern = Pattern.compile("\\b\\d{2}-\\d{2}-\\d{4}\\b");

        Matcher checkNumberMatcher = checkNumberPattern.matcher(textContent);
        Matcher dateMatcher = datePattern.matcher(textContent);

        while (checkNumberMatcher.find() && dateMatcher.find()) {
            String checkNumber = checkNumberMatcher.group(1);
            String date = dateMatcher.group();

            System.out.println("Check Number: " + checkNumber);
            System.out.println("Date: " + date);
            System.out.println();
        }
    }

    public static void extractPayeeAndAmount(String textContent) {
        String[] lines = textContent.split("\n");

        boolean inPayeeSection = false;
        boolean inAmountSection = false;
        String currentPayee = null;
        String currentAmount = null;

        for (String line : lines) {
            line = line.trim();

            if (line.isEmpty() || line.matches(".*[_-]+.*")) {
                // Skip lines with underscores/dashes or numbers and alphabets
                continue;
            }

            //System.out.println("Line: " + line);

            if ((line.matches(".*[a-zA-Z]+.*") && line.matches(".*\\d+.*"))
                    || (line.matches(".*\\d+.*") && line.matches(".*[a-zA-Z]+.*"))) {
                // Check if the line contains alphabets but not numbers
                inPayeeSection = true;
                inAmountSection = false;
                currentPayee = line;
				/*
				 * System.out.println("In Payee Section: " + inPayeeSection);
				 * System.out.println("Current Payee: " + currentPayee);
				 */

                // Split currentPayee
                splitPayee(currentPayee);

            } else if (!line.matches(".*\\d+.*") && !line.matches(".*[_-]+.*") && !line.matches(".*[a-zA-Z]+.*")) {
                // Check if the line contains numbers and doesn't contain underscores/dashes or
                // alphabets
                inAmountSection = true;
                inPayeeSection = false;
                currentAmount = line;
				/*
				 * System.out.println("In Amount Section: " + inAmountSection);
				 * System.out.println("Current Amount: " + currentAmount);
				 */
            }

            System.out.println();
        }
    }

    public static void splitPayee(String currentPayee) {
        Pattern pattern = Pattern.compile("(\\d+)?([a-zA-Z\\s]+)(\\d+)?");

        Matcher matcher = pattern.matcher(currentPayee);

        if (matcher.find()) {
            String amount = matcher.group(1);
            String payee = matcher.group(2).trim();
            String additionalAmount = matcher.group(3);

            if (amount == null && additionalAmount != null) {
                amount = additionalAmount;
            }

            System.out.println("Amount: " + (amount == null ? "0" : amount));
            System.out.println("Payee: " + payee);
        }
    }
}
