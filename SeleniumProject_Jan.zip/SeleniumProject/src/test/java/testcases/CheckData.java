package testcases;

public class CheckData {
	private String checkNumber;
	private String date;
	private String amount;
	private String payee;

	public void setCheckNumber(String checkNumber) {
		this.checkNumber = checkNumber;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public void setAmount(String amount) {
		this.amount = amount;
	}

	public void setPayee(String payee) {
		this.payee = payee;
	}

	@Override
	public String toString() {
		return "[Check Numbers = " + checkNumber + ", Dates = " + date + ", Amounts = " + amount + ", Payee = " + payee
				+ "]";
	}
}