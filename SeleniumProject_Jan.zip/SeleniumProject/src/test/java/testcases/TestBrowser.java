package testcases;


import java.time.Duration;
import java.util.Date;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class TestBrowser {
	
	
	public static void main(String[] args) throws InterruptedException {

		//SeleniumManager
		//ChromeOptions options = new ChromeOptions();
		//options.addArguments("--headless=new");
		
		
		WebDriver driver = new ChromeDriver();
		driver.get("http://gmail.com");
		driver.manage().window().maximize();
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(50));
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(5));
	
		Date d = new Date();
		System.out.println(d.toString());
		
		System.out.println(driver.getTitle());
		String title = driver.getTitle();
		System.out.println(title.length());
		driver.getTitle().length();
		/*WebElement username = driver.findElement(By.id("identifierId"));
		username.sendKeys("trainer@way2automation.com");
		
		WebElement nxtBtn = driver.findElement(By.xpath("//*[@id=\"identifierNext\"]/div/button/span"));
		nxtBtn.click();*/
		//driver.findElement(By.id("identifierId")).sendKeys("java@way2automation.com");
		wait.until(ExpectedConditions.presenceOfElementLocated(By.id("identifierId"))).sendKeys("trainer@way2automation.com");                         
		
		
		driver.findElement(By.xpath("//*[@id=\"identifierNext\"]/div/button/span")).click();
		wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//*[@id=\"password\"]/div[1]/div/div[1]/input"))).sendKeys("sdfdsfsd");                         
		//driver.findElement(By.xpath("//*[@id=\"password\"]/div[1]/div/div[1]/input")).sendKeys("sdfsfsdf");
	}

}
