package testcases;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import extentlisteners.ExtentListeners;

public class TestProperties {

	/*
	 * log4j dep Logger.getLogger() info(),error(),debug() file,html,smtp,console
	 * timestamp, append=true log4j.properties - PropertyConfigurator
	 * 
	 */

	private static WebDriver driver;
	private static Properties OR = new Properties();
	private static Properties config = new Properties();
	private static FileInputStream fis;
	private static Logger log = Logger.getLogger(TestProperties.class);

	public static void click(String locatorKey) {

		if (locatorKey.endsWith("_ID")) {
			driver.findElement(By.id(OR.getProperty(locatorKey))).click();
		} else if (locatorKey.endsWith("_XPATH")) {
			driver.findElement(By.xpath(OR.getProperty(locatorKey))).click();
		} else if (locatorKey.endsWith("_CSS")) {
			driver.findElement(By.cssSelector(OR.getProperty(locatorKey))).click();
		}
		log.info("clicking on " + locatorKey);
		ExtentListeners.test.info("clicking on " + locatorKey);
	}

	public static void type(String locatorKey, String value) {

		if (locatorKey.endsWith("_ID")) {
			driver.findElement(By.id(OR.getProperty(locatorKey))).sendKeys(value);
		} else if (locatorKey.endsWith("_XPATH")) {
			driver.findElement(By.xpath(OR.getProperty(locatorKey))).sendKeys(value);
		} else if (locatorKey.endsWith("_CSS")) {
			driver.findElement(By.cssSelector(OR.getProperty(locatorKey))).sendKeys(value);
		}
		log.info("Typing in " + locatorKey + " element and entered the value as " + value);
		ExtentListeners.test.info("Typing in " + locatorKey + " element and entered the value as " + value);
	}

	public static void main(String[] args) throws IOException {

		PropertyConfigurator.configure("./src/test/resources/properties/log4j.properties");

		log.info("Test Execution started");

		fis = new FileInputStream("./src/test/resources/properties/OR.properties");
		OR.load(fis);

		log.info("OR Properties file loaded");

		fis = new FileInputStream("./src/test/resources/properties/config.properties");
		config.load(fis);

		log.info("Config Properties file loaded");

		// driver.findElement(By.id(OR.getProperty("username_ID"))).sendKeys
		System.out.println(OR.getProperty("username_ID"));

		// driver.get(config.get("testsiteurl"))
		System.out.println(config.get("testsiteurl"));

		if (config.getProperty("browser").equals("chrome")) {

			driver = new ChromeDriver();
			log.info("Chrome browser launched");

		} else if (config.getProperty("browser").equals("firefox")) {

			driver = new FirefoxDriver();
			log.info("Firefox browser launched");

		}

		driver.get(config.getProperty("testsiteurl"));
		log.info("Navigated to : " + config.getProperty("testsiteurl"));

		driver.manage().window().maximize();
		driver.manage().timeouts()
				.implicitlyWait(Duration.ofSeconds(Integer.parseInt(config.getProperty("implicit.wait"))));

		type("username_XPATH", "trainer@way2automation.com");
		click("nextBtn_XPATH");

		driver.quit();

		log.info("test execution completed");

	}

}
