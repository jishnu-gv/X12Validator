package testcases;

import java.util.HashMap;
import java.util.Map;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.devtools.DevTools;
import org.openqa.selenium.devtools.HasDevTools;

public class TestDeviceMetricsOverride {

	public static void main(String[] args) {



		ChromeDriver driver = new ChromeDriver();
		DevTools devTools = ((HasDevTools) driver).getDevTools();
		devTools.createSession();
	
		
		//devTools.send(Emulation.setDeviceMetricsOverride(600,1000,50,true,Optional.absent(),Optional.absent(),Optional.absent(),Optional.absent(),Optional.absent(),Optional.absent(),Optional.absent(),Optional.absent(),Optional.absent()));

		Map<String,Object> deviceMetrics = new HashMap<String,Object>(){{
			
			put("width",600);
			put("height",1000);
			put("mobile",true);
			put("deviceScaleFactor",50);
			
		}};
		
		
		
		driver.executeCdpCommand("Emulation.setDeviceMetricsOverride", deviceMetrics);
		
		driver.get("http://selenium.dev");
		
		
		
	}

}
