package testcases;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class AmountExtractor {
    public static void main(String[] args) {
        String textContent = "_______________________________ 1015\n" +
                             "002003004 1095857723 1015\n" +
                             "_______________________________ 1016\n" +
                             "002003004 1095857723 1016\n" +
                             "_______________________________ 1017\n" +
                             "002003004 1095857723 1017\n" +
                             "01-08-2024\n" +
                             "4500BEST BUY\n" +
                             "FOUR THOUSAND FIVE HUNDRED DOLLARS ONLY\n" +
                             "01-09-2024\n" +
                             "WALLMART 5000\n" +
                             "FIVE THOUSAND DOLLARS ONLY\n" +
                             "01-10-2024\n" +
                             "3000APPLE CORP\n" +
                             "THREE THOUSAND DOLLARS ONLY";

        String amountPattern = "\\b\\d+\\b"; // Match one or more digits as whole words

        Pattern pattern = Pattern.compile(amountPattern);
        Matcher matcher = pattern.matcher(textContent);

        System.out.println("Extracted Amounts:");
        while (matcher.find()) {
            String amount = matcher.group();
            System.out.println(amount);
        }
    }
}

