package testcases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestNewWindow {

	public static void main(String[] args) {


		WebDriver driver = new ChromeDriver();
		driver.get("https://sso.teachable.com/secure/673/identity/sign_up/email");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
	
		
		driver.switchTo().newWindow(WindowType.TAB);
		driver.get("http://google.com");
		driver.findElement(By.name("q")).sendKeys("Hello Selenium !!!");
		
		
		driver.switchTo().newWindow(WindowType.WINDOW);
		driver.get("http://gmail.com");
		driver.findElement(By.xpath("/html/body/header/div/div/div/a[2]")).click();
		driver.findElement(By.id("identifierId")).sendKeys("trainer@way2automation.com");
		
		System.out.println(driver.getWindowHandles().size());
		
		
		
	}

}
