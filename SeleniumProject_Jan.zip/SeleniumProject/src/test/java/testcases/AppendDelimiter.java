package testcases;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class AppendDelimiter {

    public static void main(String[] args) {
        // Specify the input file path
        String filePath = "your_input_file.txt";

        // Specify the delimiter to append at the end of each line
        String delimiter = "|";

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                // Append the delimiter to each line and print
                System.out.println(line + delimiter);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
