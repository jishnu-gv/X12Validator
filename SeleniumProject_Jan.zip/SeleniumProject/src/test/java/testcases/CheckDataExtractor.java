package testcases;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class CheckDataExtractor {

    // Initialize tempData array outside the method
    static String[][] tempData;
    static int tempindex = 0;
    
    static String[][] dataArray = new String[3][4];
    static int index = 0;

    public static void main(String[] args) throws IOException {
        String pdfFilePath = "D:\\Ramesh-Personal\\Selenium\\blank-check-template-3.pdf";
        File file = new File(pdfFilePath);
        PDDocument document = PDDocument.load(file);

        PDFTextStripper pdfTextStripper = new PDFTextStripper();
        String textContent = pdfTextStripper.getText(document);

        System.out.println(textContent);

        // Close the document
        document.close();

        extractData(textContent);

        // Read Excel data and check for matches
        readExcelDataAndCheckMatches("D:\\Ramesh-Personal\\Selenium\\SampleCheckData.xlsx");
    }

    public static void extractData(String textContent) {
        Pattern checkNumberPattern = Pattern.compile("_{30,} (\\d{4,})");
        Pattern datePattern = Pattern.compile("\\b\\d{2}-\\d{2}-\\d{4}\\b");

        Matcher checkNumberMatcher = checkNumberPattern.matcher(textContent);
        Matcher dateMatcher = datePattern.matcher(textContent);

        
        // Initialize tempData array with the maximum possible size
        tempData = new String[textContent.split("\n").length][2];

        while (checkNumberMatcher.find() && dateMatcher.find()) {
            String checkNumber = checkNumberMatcher.group(1);
            String date = dateMatcher.group();

            dataArray[index][0] = checkNumber;
            dataArray[index][1] = date;

            System.out.println("Processing Check: " + checkNumber);
            System.out.println("Processing Date: " + date);

            // Split currentPayee
            splitPayee(dataArray, index, textContent);

            System.out.println("-------------------------------");

            index++;
        }

        // Display the final array
        displayArray(dataArray);
    }

    public static void splitPayee(String[][] dataArray, int index, String textContent) {
        String[] lines = textContent.split("\n");

        boolean inPayeeSection = false;
        boolean inAmountSection = false;
        String currentPayee = null;
        String currentAmount = null;

        for (String line : lines) {
            line = line.trim();

            if (line.isEmpty() || line.matches(".*[_-]+.*")) {
                // Skip lines with underscores/dashes or numbers and alphabets
                continue;
            }

            //System.out.println("Processing Line: " + line);

            if ((line.matches(".*[a-zA-Z]+.*") && line.matches(".*\\d+.*"))
                    || (line.matches(".*\\d+.*") && line.matches(".*[a-zA-Z]+.*"))) {
                // Check if the line contains alphabets but not numbers
                inPayeeSection = true;
                inAmountSection = false;
                currentPayee = line;
                System.out.println("In Payee Section: " + inPayeeSection);
                System.out.println("Current Payee: " + currentPayee);

                // Split currentPayee
                Pattern pattern = Pattern.compile("(\\d+)?([a-zA-Z\\s]+)(\\d+)?");
                Matcher matcher = pattern.matcher(currentPayee);

                if (matcher.find()) {
                    String amount = matcher.group(1);
                    String payee = matcher.group(2).trim();
                    String additionalAmount = matcher.group(3);

                    if (amount == null && additionalAmount != null) {
                        amount = additionalAmount;
                    }

                    // Check if payee and amount are already set for the current check
                    if (!containsData(tempData, tempindex, payee, amount)) {
                        // Store payee and amount in the temporary array
                        tempData[tempindex][0] = amount == null ? "0" : amount;
                        tempData[tempindex][1] = payee;

                        System.out.println(tempData[tempindex][0]);
                        System.out.println(tempData[tempindex][1]);

                        // Update the main array with data from the temporary array
                        dataArray[index][2] = tempData[tempindex][0];
                        dataArray[index][3] = tempData[tempindex][1];

                        System.out.println(dataArray[index][2]);
                        System.out.println(dataArray[index][3]);

                        tempindex++;
                        break;
                    }
                }
            } else if (!line.matches(".*\\d+.*") && !line.matches(".*[_-]+.*") && !line.matches(".*[a-zA-Z]+.*")) {
                // Check if the line contains numbers and doesn't contain underscores/dashes or
                // alphabets
                inAmountSection = true;
                inPayeeSection = false;
                currentAmount = line;

                // Store payee and amount in the temporary array
                tempData[tempindex][0] = currentAmount;
                tempData[tempindex][1] = currentPayee;

                // Check if payee and amount are already set for the current check
                if (!containsData(tempData, tempindex, currentPayee, currentAmount)) {
                    // Update the main array with data from the temporary array
                    dataArray[index][2] = tempData[tempindex][0];
                    dataArray[index][3] = tempData[tempindex][1];

                    System.out.println("In Amount Section: " + inAmountSection);
                    System.out.println("Current Amount: " + currentAmount);
                    System.out.println("Current Payee: " + currentPayee);

                    tempindex++;
                    break;
                }
            }
            System.out.println();
        }

        // Display tempData after processing each check
        displayTempArray(tempData, tempindex);
    }

    private static boolean containsData(String[][] tempData, int endIndex, String payee, String amount) {

        //System.out.println("endIndex--->" + endIndex);

        for (int i = 0; i < endIndex; i++) {
            if (tempData[i][1] != null && tempData[i][0] != null) {
                String storedPayee = tempData[i][1].trim();
                String storedAmount = tempData[i][0].trim();

                //System.out.println("Inside Match");

                if (storedPayee.equalsIgnoreCase(payee) && storedAmount.equalsIgnoreCase(amount)) {
                    System.out.println("Debug: Found existing data at index " + i);
                    System.out.println("Debug: Stored Payee: " + storedPayee);
                    System.out.println("Debug: Stored Amount: " + storedAmount);
                    System.out.println("Debug: Input Payee: " + payee);
                    System.out.println("Debug: Input Amount: " + amount);
                    return true;
                }
            }
        }
        //System.out.println("No Match");
        return false;
    }
    
    private static boolean containsData(String[][] dataArray, int endIndex, String checkNumber, String date,
            String amount, String payee) {

        for (int i = 0; i < dataArray.length; i++) {
            // Check if the current row is within bounds
            if (i < endIndex && dataArray[i].length == 4) {
                String storedCheckNumber = dataArray[i][0].trim();
                String storedDate = dataArray[i][1].trim();
                String storedAmount = dataArray[i][2].trim();
                String storedPayee = dataArray[i][3].trim();

                if (storedCheckNumber.equalsIgnoreCase(checkNumber) && storedDate.equalsIgnoreCase(date)
                        && storedAmount.equalsIgnoreCase(amount) && storedPayee.equalsIgnoreCase(payee)) {
                    System.out.println("Match Found at index " + i);
                    return true;
                }
            }
        }
        //System.out.println("No Match");
        return false;
    }

    public static void displayArray(String[][] dataArray) {
        System.out.println("Check | Date       | Amount | Payee");
        System.out.println("-------------------------------");

        for (String[] data : dataArray) {
            if (data[0] == null) {
                // Skip null entries in the array
                continue;
            }
            System.out.printf("%-6s| %-11s| %-7s| %-20s%n", data[0], data[1], data[2], data[3]);
        }
    }

    public static void displayTempArray(String[][] tempData, int endIndex) {
        System.out.println("Temp Data:");
        System.out.println("Amount | Payee");
        System.out.println("----------------");

        for (int i = 0; i < endIndex; i++) {
            System.out.printf("%-7s| %-20s%n", tempData[i][0], tempData[i][1]);
        }
    }
    public static void readExcelDataAndCheckMatches(String excelFilePath) throws IOException {
        FileInputStream inputStream = new FileInputStream(new File(excelFilePath));
        XSSFWorkbook workbook = new XSSFWorkbook(inputStream);

        // Assuming your sheet is the first sheet in the workbook
        Sheet sheet = workbook.getSheetAt(0);

        Iterator<Row> iterator = sheet.iterator();
        
        // Skip the first row (headers)
        if (iterator.hasNext()) {
            iterator.next();
        }

        while (iterator.hasNext()) {
            Row currentRow = iterator.next();
            Iterator<Cell> cellIterator = currentRow.iterator();

            // Assuming your data is in columns A, B, C, and D
            Cell checkNumberCell = cellIterator.next();
            Cell dateCell = cellIterator.next();
            Cell amountCell = cellIterator.next();
            Cell payeeCell = cellIterator.next();

            // Now you can check the cell type before retrieving its value
            String checkNumber = getStringValueFromCell(checkNumberCell);
            String date = getFormattedDateFromCell(dateCell);
            String amount = getStringValueFromCell(amountCell);
            String payee = getStringValueFromCell(payeeCell);

            // Now you can compare this data with your existing array
            // Call the method to check if it matches and print the result
            checkAndPrintResult(checkNumber, date, amount, payee, dataArray, index);


        }

        workbook.close();
        inputStream.close();
    }

    private static String getStringValueFromCell(Cell cell) {
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue();
            case NUMERIC:
                // Handle numeric values as needed, e.g., format it as a string
                return String.valueOf((long) cell.getNumericCellValue());
            default:
                return "";
        }
    }

    private static String getFormattedDateFromCell(Cell cell) {
        switch (cell.getCellType()) {
            case NUMERIC:
                // Assuming the date is stored as a numeric value (Excel date format)
                Date date = cell.getDateCellValue();
                DateFormat dateFormat = new SimpleDateFormat("MM-dd-yyyy");
                return dateFormat.format(date);
            default:
                return "";
        }
    }


    private static void checkAndPrintResult(String checkNumber, String date, String amount, String payee, String[][] dataArray, int index) {
        if (containsData(dataArray, index, checkNumber, date, amount, payee)) {
            System.out.println("Matched: " + checkNumber + ", " + date + ", " + amount + ", " + payee);
        } else {
            System.out.println("Not Matched: " + checkNumber + ", " + date + ", " + amount + ", " + payee);
        }
    }
}
