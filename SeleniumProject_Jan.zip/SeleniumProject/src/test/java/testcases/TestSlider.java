package testcases;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class TestSlider {

	public static void main(String[] args) throws InterruptedException {



		WebDriver driver = new ChromeDriver();
		driver.get("https://jqueryui.com/resources/demos/slider/default.html");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		
		
		int width = driver.findElement(By.id("slider")).getSize().width/2;
		System.out.println(width);
		System.out.println(driver.findElement(By.id("slider")).getSize());
		
		WebElement slider = driver.findElement(By.xpath("//*[@id=\"slider\"]/span"));
	
		Thread.sleep(5000);
		
		new Actions(driver).dragAndDropBy(slider, width, 0).perform();
		
		


	}

}
