package utilities;

public class TestConfig{


	
	public static String server="smtp.gmail.com";
	public static String from = "java@way2automation.com";
	public static String password = "Selenium@123";
	public static String[] to ={"seleniumcoaching@gmail.com","trainer@way2automation.com"};
	public static String subject = "Test Report";
	
	public static String messageBody ="TestMessage";
	public static String attachmentPath="C:\\Users\\way2automation\\Desktop\\Desktop\\newyear.png";
	public static String attachmentName="error.jpg";
	

	
	//MYSQL DATABASE DETAILS
	public static String mysqldriver="com.mysql.cj.jdbc.Driver";
	public static String mysqluserName = "root";
	public static String mysqlpassword = "selenium";
	public static String mysqlurl = "jdbc:mysql://localhost:3306/nov2023";
	
	
	
	
	
	
	
	
	
}
