package X12Validator;

import org.testng.annotations.Test;

public class GEValidator extends X12Utils {

	public void validateGE(String edi837) {
		// GE validation logic
		// ...
		// Perform GE segment validation
		// Example: Check GE segment length, format, values, etc.
		// If there's an error, add it to validationErrors list

		String geSegment = getSegment("GE", edi837);

		System.out.println(geSegment);

		String[] geElement = geSegment.split("~");

		// Print the elements
		for (String geelement : geElement) {
			System.out.println(geelement);

			String[] geElements = geelement.split("\\*");
			System.out.println("GE Elements:");
			for (int i = 0; i < geElements.length; i++) {
				System.out.println("Element " + (i + 1) + ": " + geElements[i]);
			}

			// Example: Check if GE segment exists
			if (geelement == null) {
				validationErrors.add("GE segment is missing.");
				return;
			}

			// Example: Check GE segment length
			if (geelement.length() != 10) {
				validationErrors.add("GE segment has an invalid length.");
			}

			// Example: Validate GE01 is "GE"
			if (!getField(geelement, 1).equals("GE")) {
				validationErrors.add("GE01 must be 'GE'.");
			}

			// Example: Validate GE02 is "01"
			if (!getField(geelement, 2).equals("1")) {
				validationErrors.add("GE02 must be '1'.");
			}

			// Example: Validate GE03 is "72602"
			if (!getField(geelement, 3).equals("72602")) {
				validationErrors.add("GE03 must be '72602'.");
			}

		}
	}
}
