package X12Validator;

import org.testng.annotations.Test;

public class CLMValidator extends X12Utils {

	public void validateCLM(String edi837) {
		// CLM validation logic
		// ...
		// Perform CLM segment validation
		// Example: Check CLM segment length, format, values, etc.
		// If there's an error, add it to validationErrors list

		String clmSegment = getSegment("CLM", edi837);

		System.out.println(clmSegment);

		String[] clmElement = clmSegment.split("~");

		// Print the elements
		for (String clmelement : clmElement) {
			System.out.println(clmelement);

			String[] clmElements = clmelement.split("\\*");
			System.out.println("CLM Elements:");
			for (int i = 0; i < clmElements.length; i++) {
				System.out.println("Element " + (i + 1) + ": " + clmElements[i]);
			}

			// Example: Check if CLM segment exists
			if (clmelement == null) {
				validationErrors.add("CLM segment is missing.");
				return;
			}

			// Example: Check CLM segment length
			if (clmelement.length() != 37) {
				validationErrors.add("CLM segment has an invalid length.");
			}

			// Example: Validate CLM01 is "CLM"
			if (!getField(clmelement, 1).equals("CLM")) {
				validationErrors.add("CLM01 must be 'CLM'.");
			}

			// Example: Validate CLM02 is "D8"
			if (!getField(clmelement, 2).equals("KPU962501336")) {
				validationErrors.add("CLM02 must be 'KPU962501336'.");
			}

			
		}
	}
}
