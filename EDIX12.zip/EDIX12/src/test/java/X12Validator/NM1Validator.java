package X12Validator;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class NM1Validator extends X12Utils{

	public void validateNM1(String edi837) {
		List<String> nm1Segments = X12Utils.getAllNM1Segments(edi837);
		// NM1 validation logic
		// ...
		System.out.println(nm1Segments);
		
		 for (String nm1Segment : nm1Segments) {
	            boolean isValid = validateNM1Segment(nm1Segment);
	            System.out.println("Validation Result: " + isValid);
	        }
		

	}
	
	private static boolean validateNM1Segment(String nm1Segment) {
        // Construct a flexible NM1 segment pattern
        
		// Define multiple patterns for NM1 segments
        //String pattern1 = "NM1\\*([^*]+)\\*([^*]+)\\*([^*]+)\\*([^*]+)\\*([^*]*)\\*([^*]*)\\*([^*]*)\\*([^~]+)~";
    	String pattern1 = "NM1\\*([^*]+)\\*([^*]+)\\*([^*]+)\\*([^*]+)\\*.*?\\*([^*]+)\\*([^~]+)~";
        String pattern2 = "NM1\\*([^*]+)\\*([^*]+)\\*([^*]+)\\*.*?\\*([^*]+)\\*([^~]+)~";

        // Apply patterns sequentially
        if (matchesPattern1(nm1Segment, pattern1)) {
            System.out.println("Using Pattern 1");
            return true;
        } else if (matchesPattern2(nm1Segment, pattern2)) {
            System.out.println("Using Pattern 2");
            return true;
        } else {
            System.out.println("No match found. NM1 Segment: " + nm1Segment);
            return false;
        }
    }

	private static boolean matchesPattern1(String input, String pattern) {
        // Compile the regular expression pattern
        Pattern compiledPattern = Pattern.compile(pattern);
        Matcher matcher = compiledPattern.matcher(input);

        // Check if the pattern matches
        if (matcher.find()) {
            // Extract and print values for debugging
            for (int i = 1; i <= matcher.groupCount(); i++) {
                System.out.println("Group " + i + ": " + matcher.group(i));
            }

            // Perform validations...
            
         // Perform validations based on specific group values
            String group1Value = matcher.group(1);
            String group2Value = matcher.group(2);
            String group3Value = matcher.group(3);
            String group4Value = matcher.group(4);
            String group5Value = matcher.group(5);
            String group6Value = matcher.group(6);
            
                      
            System.out.println("group1Value:"+ group1Value);
            System.out.println("group2Value:"+ group2Value);
            System.out.println("group3Value:"+ group3Value);
            System.out.println("group4Value:"+ group4Value);
            System.out.println("group5Value:"+ group5Value);
            System.out.println("group6Value:"+ group6Value);


            // Example validations:
            if ("IL".equals(group1Value)) {
                // Validation for group1Value being "IL"
                System.out.println("Validation for IL passed.");
            }

            if ("1".equals(group2Value)) {
                // Validation for group2Value being "1"
                System.out.println("Validation for 1 passed.");
            }

            // Return the result of validations
            return true; // For now, consider it valid
        }
		return false;
    }
        
        private static boolean matchesPattern2(String input, String pattern) {
            // Compile the regular expression pattern
            Pattern compiledPattern = Pattern.compile(pattern);
            Matcher matcher = compiledPattern.matcher(input);

            // Check if the pattern matches
            if (matcher.find()) {
                // Extract and print values for debugging
                for (int i = 1; i <= matcher.groupCount(); i++) {
                    System.out.println("Group " + i + ": " + matcher.group(i));
                }

                // Perform validations...
                
             // Perform validations based on specific group values
                String group1Value = matcher.group(1);
                String group2Value = matcher.group(2);
                String group3Value = matcher.group(3);
                String group4Value = matcher.group(4);
                String group5Value = matcher.group(5);
                
                
                System.out.println("group1Value:"+ group1Value);
                System.out.println("group2Value:"+ group2Value);
                System.out.println("group3Value:"+ group3Value);
                System.out.println("group4Value:"+ group4Value);
                System.out.println("group5Value:"+ group5Value);
                

                // Example validations:
                if ("PR".equals(group1Value)) {
                    // Validation for group1Value being "PR"
                    System.out.println("Validation for PR passed.");
                }

                if ("2".equals(group2Value)) {
                    // Validation for group2Value being "2"
                    System.out.println("Validation for 2 passed.");
                }

                // Return the result of validations
                return true; // For now, consider it valid
            }


        return false; // Pattern did not match
    }
}
