package X12Validator;

import org.testng.annotations.Test;
import java.io.File;
import java.io.IOException;

public class EDI837ValidatorD {
	
	private String folderPath = "D:\\Ramesh-Personal\\Selenium\\EDI837Files";

    @Test
    public void validateMultipleEDI837Files() {
        // List all files in the folder
        File folder = new File(folderPath);
        File[] files = folder.listFiles();

        if (files != null) {
            for (File file : files) {
                if (file.isFile() && file.getName().endsWith(".x12")|| file.getName().endsWith(".txt")) {
                    processEDI837File(file);
                }
            }
        } else {
            System.out.println("No files found in the specified folder.");
        }
    }

    private void processEDI837File(File file) {
        String edi837;
        try {
            // Load content from the file
            edi837 = X12FileLoader.loadX12File(file.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }

        System.out.println("Processing file: " + file.getName());
        System.out.println(edi837);

        EDI837ValidatorEngine validatorEngine = new EDI837ValidatorEngine();
        validatorEngine.validateEDI837(edi837);
    }

	
	
}
