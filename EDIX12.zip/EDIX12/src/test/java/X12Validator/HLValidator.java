package X12Validator;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HLValidator extends X12Utils {

	public void validateHL(String edi837) {
		List<String> hlSegments = X12Utils.getAllHLSegments(edi837);
		// NM1 validation logic
		// ...
		System.out.println(hlSegments);

		for (String hlSegment : hlSegments) {
			boolean isValid = validateHLSegment(hlSegment);
			System.out.println("Validation Result: " + isValid);

		}
	}

	public boolean validateHLSegment(String hlSegment) {
		// Construct a flexible HL segment pattern
		// String segmentPattern = "HL\\*(\\d+)\\*(\\d+)\\*(\\d+)?\\*(\\d+)?~";

		String segmentPattern = "HL\\*(\\d+)\\*(\\d+)?\\*(\\d+)?\\*(\\d+)?~";

		// Compile the regular expression pattern
		Pattern pattern = Pattern.compile(segmentPattern);
		Matcher matcher = pattern.matcher(hlSegment);

		// Check if the pattern matches
		if (matcher.find()) {
			// Extract and print values for debugging
			for (int i = 1; i <= matcher.groupCount(); i++) {
				System.out.println("Group " + i + ": " + matcher.group(i));
			}

			// Perform validations...
			// You can add your validations here
			String group1Value = matcher.group(1);
			String group2Value = matcher.group(2);
			String group3Value = matcher.group(3);
			String group4Value = matcher.group(4);

			System.out.println(group1Value);
			System.out.println(group2Value);
			System.out.println(group3Value);
			System.out.println(group4Value);

			String hl03 = matcher.group(3);
			if (hl03 != null && !hl03.isEmpty()) {
				int hl03Value = Integer.parseInt(hl03);
				if (hl03Value < 0 || hl03Value > 100) {
					System.out.println("HL03 is outside the valid range (0-100).");
					return false;
				}
			}
			
			// You can add more validations based on your requirements

			// Return the result of validations
			return true; // For now, consider it valid
		} else {
			// Print the entire HL segment when no match is found
			System.out.println("No match found. HL Segment: " + hlSegment);

		}

		return false; // Pattern did not match
	}

	// Other helper methods and fields...
}
