package X12Validator;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class HCPValidator extends X12Utils {

	public void validateHCP(String edi837) {
		// HCP validation logic
		// ...

		List<String> hcpSegments = X12Utils.getAllHCPSegments(edi837);
		// HCP validation logic
		// ...
		System.out.println(hcpSegments);

		for (String hcpSegment : hcpSegments) {
			boolean isValid = validateHCPSegment(hcpSegment);
			System.out.println("Validation Result: " + isValid);

		}

	}

	public boolean validateHCPSegment(String hcpSegment) {
		// Construct a flexible HCP segment pattern

		// Construct a flexible HCP segment pattern
		String segmentPattern = "HCP\\*([^*]+)\\*([^*]+)\\*([^~]+)~";

		// Compile the regular expression pattern
		Pattern pattern = Pattern.compile(segmentPattern);
		Matcher matcher = pattern.matcher(hcpSegment);

		// Check if the pattern matches
		if (matcher.find()) {
			// Extract and print values for debugging
			System.out.println(matcher.groupCount());
			for (int i = 1; i <= matcher.groupCount(); i++) {
				System.out.println("Group " + i + ": " + matcher.group(i));
			}

			// Perform additional validations...
			String group1 = matcher.group(1); // Accessing captured groups
			String group2 = matcher.group(2);
			String group3 = matcher.group(3);

			// Example additional validations
			if (!"00".equals(group1)) {
				System.out.println("Validation error: Invalid value for HCP field 1");
				return false;
			}

			if (!"0".equals(group2)) {
				System.out.println("Validation error: Invalid value for HCP field 2");
				return false;
			}

			// Add more validations as needed...

			// Return the result of validations
			return true; // For now, consider it valid

		} else {
			// Print the entire HCP segment when no match is found
			System.out.println("No match found. HCP Segment: " + hcpSegment);
		}

		return false; // Pattern did not match
	}
}
