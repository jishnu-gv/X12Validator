package X12Validator;

import org.testng.annotations.Test;

public class IEAValidator extends X12Utils {

	public void validateIEA(String edi837) {
		// IEA validation logic
		// ...
		// Perform IEA segment validation
		// Example: Check IEA segment length, format, values, etc.
		// If there's an error, add it to validationErrors list

		String ieaSegment = getSegment("IEA", edi837);

		System.out.println(ieaSegment);

		String[] ieaElement = ieaSegment.split("~");

		// Print the elements
		for (String ieaelement : ieaElement) {
			System.out.println(ieaelement);

			String[] ieaElements = ieaelement.split("\\*");
			System.out.println("IEA Elements:");
			for (int i = 0; i < ieaElements.length; i++) {
				System.out.println("Element " + (i + 1) + ": " + ieaElements[i]);
			}

			// Example: Check if IEA segment exists
			if (ieaelement == null) {
				validationErrors.add("IEA segment is missing.");
				return;
			}

			// Example: Check IEA segment length
			if (ieaelement.length() != 15) {
				validationErrors.add("IEA segment has an invalid length.");
			}

			// Example: Validate IEA01 is "IEA"
			if (!getField(ieaelement, 1).equals("IEA")) {
				validationErrors.add("IEA01 must be 'IEA'.");
			}

			// Example: Validate IEA02 is "1"
			if (!getField(ieaelement, 2).equals("1")) {
				validationErrors.add("IEA02 must be '1'.");
			}

			// Example: Validate IEA03 is "000115606"
			if (!getField(ieaelement, 2).equals("000115606")) {
				validationErrors.add("IEA03 must be '000115606'.");
			}

		}
	}
}
