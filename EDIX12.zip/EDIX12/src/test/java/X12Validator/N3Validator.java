package X12Validator;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class N3Validator extends X12Utils {

	public void validateN3(String edi837) {
		// N3 validation logic
		// ...

		List<String> n3Segments = X12Utils.getAllN3Segments(edi837);
		// N3 validation logic
		// ...
		System.out.println(n3Segments);

		for (String n3Segment : n3Segments) {
			boolean isValid = validateN3Segment(n3Segment);
			System.out.println("Validation Result: " + isValid);

		}

	}

	public boolean validateN3Segment(String n3Segment) {
		// Construct a flexible N3 segment pattern
		String segmentPattern = "N3\\*([^~]+)~";

		// Compile the regular expression pattern
		Pattern pattern = Pattern.compile(segmentPattern);
		Matcher matcher = pattern.matcher(n3Segment);

		// Check if the pattern matches
		if (matcher.find()) {
			// Extract and print values for debugging
			for (int i = 1; i <= matcher.groupCount(); i++) {
				System.out.println("Group " + i + ": " + matcher.group(i));
			}

			// Perform validations...
			String n3Address = matcher.group(1);
			if (n3Address != null && !n3Address.isEmpty()) {
				// Validation 1: Check if the address is not empty
				System.out.println("Address is not empty.");

				// Validation 2: Check if the address contains valid characters
				if (n3Address.matches("^[a-zA-Z0-9\\s]+$")) {
					System.out.println("Address contains valid characters.");
				} else {
					System.out.println("Address contains invalid characters.");
					return false;
				}

				// You can add more validations based on your requirements
			} else {
				System.out.println("Address is empty.");
				return false;
			}

			// Return the result of validations
			return true; // For now, consider it valid
		} else {
			// Print the entire N3 segment when no match is found
			System.out.println("No match found. N3 Segment: " + n3Segment);
		}

		return false; // Pattern did not match
	}
}
