package X12Validator;

import org.testng.annotations.Test;

public class SEValidator extends X12Utils {

	public void validateSE(String edi837) {
		// SE validation logic
		// ...
		// Perform SE segment validation
		// Example: Check SE segment length, format, values, etc.
		// If there's an error, add it to validationErrors list

		String seSegment = getSegment("SE", edi837);

		System.out.println(seSegment);

		String[] seElement = seSegment.split("~");

		// Print the elements
		for (String seelement : seElement) {
			System.out.println(seelement);

			String[] seElements = seelement.split("\\*");
			System.out.println("SE Elements:");
			for (int i = 0; i < seElements.length; i++) {
				System.out.println("Element " + (i + 1) + ": " + seElements[i]);
			}

			// Example: Check if SE segment exists
			if (seelement == null) {
				validationErrors.add("SE segment is missing.");
				return;
			}

			// Example: Check SE segment length
			if (seelement.length() != 10) {
				validationErrors.add("SE segment has an invalid length.");
			}

			// Example: Validate SE01 is "SE"
			if (!getField(seelement, 1).equals("SE")) {
				validationErrors.add("SE01 must be 'SE'.");
			}

			// Example: Validate SE02 is "53"
			if (!getField(seelement, 2).equals("53")) {
				validationErrors.add("DMG02 must be '53'.");
			}

			// Example: Validate SE03 is "0001"
			if (!getField(seelement, 3).equals("0001")) {
				validationErrors.add("DMG02 must be '0001'.");
			}

		}
	}
}
