package X12Validator;

import org.testng.annotations.Test;

public class DMGValidator extends X12Utils {

	public void validateDMG(String edi837) {
		// DMG validation logic
		// ...
		// Perform DMG segment validation
		// Example: Check DMG segment length, format, values, etc.
		// If there's an error, add it to validationErrors list

		String dmgSegment = getSegment("DMG", edi837);

		System.out.println(dmgSegment);

		String[] dmgElement = dmgSegment.split("~");

		// Print the elements
		for (String dmgelement : dmgElement) {
			System.out.println(dmgelement);

			String[] dmgElements = dmgelement.split("\\*");
			System.out.println("DMG Elements:");
			for (int i = 0; i < dmgElements.length; i++) {
				System.out.println("Element " + (i + 1) + ": " + dmgElements[i]);
			}

			// Example: Check if GS segment exists
			if (dmgelement == null) {
				validationErrors.add("DMG segment is missing.");
				return;
			}

			// Example: Check DMG segment length
			if (dmgelement.length() != 17) {
				validationErrors.add("DMG segment has an invalid length.");
			}

			// Example: Validate DMG01 is "SBR"
			if (!getField(dmgelement, 1).equals("DMG")) {
				validationErrors.add("DMG01 must be 'DMG'.");
			}

			// Example: Validate DMG02 is "D8"
			if (!getField(dmgelement, 2).equals("D8")) {
				validationErrors.add("DMG02 must be 'D8'.");
			}

			String dateStr = getField(dmgelement, 3);

			// Validate date and time
			boolean isDateValid = isValidDateY(dateStr);

			System.out.println("Is Date Valid for DMR? " + isDateValid);

		}
	}
}
