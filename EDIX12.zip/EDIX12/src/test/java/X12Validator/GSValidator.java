package X12Validator;

import org.testng.annotations.Test;

public class GSValidator extends X12Utils {
	
	
    public void validateGS(String edi837) {
        // GS validation logic
        // ...
    	// Perform GS segment validation
    			// Example: Check GS segment length, format, values, etc.
    			// If there's an error, add it to validationErrors list

    			String gsSegment = getSegment("GS", edi837);

    			System.out.println(gsSegment);

    			String[] gsElement = gsSegment.split("~");

    			// Print the elements
    			for (String gselement : gsElement) {
    				System.out.println(gselement);

    				String[] gsElements = gselement.split("\\*");
    				System.out.println("GS Elements:");
    				for (int i = 0; i < gsElements.length; i++) {
    					System.out.println("Element " + (i + 1) + ": " + gsElements[i]);
    				}

    				// Example: Check if GS segment exists
    				if (gselement == null) {
    					validationErrors.add("GS segment is missing.");
    					return;
    				}

    				// Example: Check GS segment length
    				if (gselement.length() != 55) {
    					validationErrors.add("GS segment has an invalid length.");
    				}

    				// Example: Validate GS01 is "GS"
    				if (!getField(gselement, 1).equals("GS")) {
    					validationErrors.add("GS01 must be 'GS'.");
    				}

    				// Example: Validate GS02 is "HC"
    				if (!getField(gselement, 2).equals("HC")) {
    					validationErrors.add("GS02 must be 'HC'.");
    				}

    				String dateStr = getField(gselement, 5);
    				String timeStr = getField(gselement, 6);

    				// Validate date and time
    				boolean isDateValid = isValidDateY(dateStr);
    				boolean isTimeValid = isValidTime(timeStr);

    				System.out.println("Is Date Valid for GS? " + isDateValid);
    				System.out.println("Is Time Valid for GS? " + isTimeValid);

    				// Add more validations as needed

    				// Example: Validate GS07 is "72602"
    				if (!getField(gselement, 7).equals("72602")) {
    					System.out.println("GS7 segment is valid 72602.");
    				}

    				// Example: Validate GS09 is "005010X224A2"
    				if (!getField(gselement, 9).equals("005010X224A2")) {
    					validationErrors.add("GS09 must be '005010X224A2.");
    				}

    			}
    }
}
