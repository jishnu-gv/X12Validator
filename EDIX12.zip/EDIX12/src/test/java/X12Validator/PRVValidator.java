package X12Validator;

import org.testng.annotations.Test;

public class PRVValidator extends X12Utils {

	public void validatePRV(String edi837) {
		// PRV validation logic
		// ...
		// Perform PRV segment validation
		// Example: Check PRV segment length, format, values, etc.
		// If there's an error, add it to validationErrors list

		String prvSegment = getSegment("PRV", edi837);

		System.out.println(prvSegment);

		String[] prvElement = prvSegment.split("~");

		// Print the elements
		for (String prvelement : prvElement) {
			System.out.println(prvelement);

			String[] prvElements = prvelement.split("\\*");
			System.out.println("PRV Elements:");
			for (int i = 0; i < prvElements.length; i++) {
				System.out.println("Element " + (i + 1) + ": " + prvElements[i]);
			}

			// Example: Check if PRV segment exists
			if (prvelement == null) {
				validationErrors.add("PRV segment is missing.");
				return;
			}

			// Example: Check PRV segment length
			if (prvelement.length() != 21) {
				validationErrors.add("CLM segment has an invalid length.");
			}

			// Example: Validate PRV01 is "PRV"
			if (!getField(prvelement, 1).equals("PRV")) {
				validationErrors.add("CLM01 must be 'PRV'.");
			}

			// Example: Validate PRV02 is "PE"
			if (!getField(prvelement, 2).equals("PE")) {
				validationErrors.add("PRV02 must be 'PE'.");
			}
			// Example: Validate PRV03 is "PXC"
			if (!getField(prvelement, 3).equals("PXC")) {
				validationErrors.add("PRV03 must be 'PXC'.");
			}

		}
	}
}
