package X12Validator;

import org.testng.annotations.Test;

public class SBRValidator extends X12Utils {

	public void validateSBR(String edi837) {
		// SBR validation logic
		// ...
		// Perform SBR segment validation
		// Example: Check SBR segment length, format, values, etc.
		// If there's an error, add it to validationErrors list

		String sbrSegment = getSegment("SBR", edi837);

		System.out.println(sbrSegment);

		String[] sbrElement = sbrSegment.split("~");

		// Print the elements
		for (String sbrelement : sbrElement) {
			System.out.println(sbrelement);

			String[] sbrElements = sbrelement.split("\\*");
			System.out.println("SBR Elements:");
			for (int i = 0; i < sbrElements.length; i++) {
				System.out.println("Element " + (i + 1) + ": " + sbrElements[i]);
			}

			// Example: Check if SBR segment exists
			if (sbrelement == null) {
				validationErrors.add("SBR segment is missing.");
				return;
			}

			// Example: Check SBR segment length
			if (sbrelement.length() != 22) {
				validationErrors.add("SBR segment has an invalid length.");
			}

			// Example: Validate SBR01 is "SBR"
			if (!getField(sbrelement, 1).equals("SBR")) {
				validationErrors.add("SBR01 must be 'SBR'.");
			}

			// Example: Validate SBR02 is "P"
			if (!getField(sbrelement, 2).equals("P")) {
				validationErrors.add("SBR02 must be 'P'.");
			}

			// Example: Validate SBR03 is "18"
			if (!getField(sbrelement, 3).equals("18")) {
				System.out.println("SBR03 must be '18'.");
			}

			// Example: Validate SBR04 is "50625"
			if (!getField(sbrelement, 4).equals("50625")) {
				validationErrors.add("SBR04 must be '50625.");
			}
			
			// Example: Validate SBR10 is "CI"
			if (!getField(sbrelement, 10).equals("CI")) {
				validationErrors.add("SBR04 must be 'CI'.");
			}

		}
	}
}
