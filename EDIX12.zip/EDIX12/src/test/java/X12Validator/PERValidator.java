package X12Validator;

public class PERValidator extends X12Utils {

	public void validatePER(String edi837) {
		// PER validation logic
		// ...
		// Perform PER segment validation
		// Example: Check PER segment length, format, values, etc.
		// If there's an error, add it to validationErrors list

		String perSegment = getSegment("PER", edi837);

		System.out.println(perSegment);

		String[] perElement = perSegment.split("~");

		// Print the elements
		for (String perelement : perElement) {
			System.out.println(perelement);

			String[] perElements = perelement.split("\\*");
			System.out.println("PER Elements:");
			for (int i = 0; i < perElements.length; i++) {
				System.out.println("Element " + (i + 1) + ": " + perElements[i]);
			}

			// Example: Check if PER segment exists
			if (perelement == null) {
				validationErrors.add("PER segment is missing.");
				return;
			}

			// Example: Check PER segment length
			if (perelement.length() != 50) {
				validationErrors.add("PER segment has an invalid length.");
			}

			// Example: Validate PER01 is "PER"
			if (!getField(perelement, 1).equals("PER")) {
				validationErrors.add("PER01 must be 'PER'.");
			}

			// Example: Validate PER02 is "IC"
			if (!getField(perelement, 2).equals("IC")) {
				validationErrors.add("PER02 must be 'IC'.");
			}

			// Example: Validate PER03 is not empty
			if (getField(perelement, 3).isEmpty()) {
				validationErrors.add("PER03 (Name) cannot be empty.");
			}

			// Example: Validate PER04 is "EM"
			if (!getField(perelement, 4).equals("EM")) {
				validationErrors.add("PER04 must be 'EM'.");
			}

			// Example: Validate PER04 is a valid email address
			String email = getField(perelement, 5);
			if (!isValidEmailAddress(email)) {
				validationErrors.add("PER05 must be a valid email address.");
			}
		}

		// Add more validation methods as needed

	}

	private boolean isValidEmailAddress(String email) {
		// Add your email validation logic here
		// You can use a regular expression or a library for email validation
		// For simplicity, let's check if the email contains '@'
		return email.contains("@");
	}

}
