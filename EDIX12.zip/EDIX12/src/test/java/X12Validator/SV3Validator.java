package X12Validator;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SV3Validator extends X12Utils {

	public void validateSV3(String edi837) {
		List<String> sv3Segments = X12Utils.getAllSV3Segments(edi837);
		// SV3 validation logic
		// ...
		System.out.println(sv3Segments);

		for (String sv3Segment : sv3Segments) {
			boolean isValid = validateSV3Segment(sv3Segment);
			System.out.println("Validation Result: " + isValid);

		}
	}

	public boolean validateSV3Segment(String sv3Segment) {
		// Construct a flexible SV3 segment pattern

		String segmentPattern = "SV3\\*AD:([^*]+)\\*([^*]+)\\*([^*]+)\\*([^*]+)\\*([^~]+)~";

		// Compile the regular expression pattern
		Pattern pattern = Pattern.compile(segmentPattern);
		Matcher matcher = pattern.matcher(sv3Segment);

		// Check if the pattern matches
		if (matcher.find()) {
			// Extract and print values for debugging
			for (int i = 1; i <= matcher.groupCount(); i++) {
				System.out.println("Group " + i + ": " + matcher.group(i));
			}

			// Perform additional validations if needed...

			// Additional validations based on extracted values
			String code = matcher.group(1);
			int quantity = Integer.parseInt(matcher.group(2));
			int qualifier = Integer.parseInt(matcher.group(3));
			double amount = Double.parseDouble(matcher.group(4));

			// Example additional validations (replace with your own logic)
			if (!isValidCode(code)) {
				System.out.println("Invalid code: " + code);
				return false;
			}

			if (quantity <= 0) {
				System.out.println("Quantity must be greater than 0.");
				return false;
			}

			return true; // For now, consider it valid
		} else {
			System.out.println("No match found. SV3 Segment: " + sv3Segment);
			return false; // Pattern did not match
		}

	}
	// Other helper methods and fields...

	// Example validation method for code (replace with your own logic)
	private boolean isValidCode(String code) {
		// Placeholder logic, replace with your own code validation logic
		return code != null && code.matches("[A-Za-z0-9]+");
	}
}
