package X12Validator;

public class STValidator extends X12Utils{

    public void validateST(String edi837) {
        // ST validation logic
        // ...
    	// Perform ST segment validation
    			// Example: Check ST segment length, format, values, etc.
    			// If there's an error, add it to validationErrors list

    			String stSegment = getSegment("ST", edi837);

    			System.out.println(stSegment);

    			String[] stElement = stSegment.split("~");

    			// Print the elements
    			for (String stelement : stElement) {
    				System.out.println(stelement);

    				String[] stElements = stelement.split("\\*");
    				System.out.println("ST Elements:");
    				for (int i = 0; i < stElements.length; i++) {
    					System.out.println("Element " + (i + 1) + ": " + stElements[i]);
    				}

    				// Example: Check if ST segment exists
    				if (stelement == null) {
    					validationErrors.add("ST segment is missing.");
    					return;
    				}

    				// Example: Check ST segment length
    				if (stelement.length() != 24) {
    					validationErrors.add("ST segment has an invalid length.");
    				}

    				// Example: Validate ST01 is "ST"
    				if (!getField(stelement, 1).equals("ST")) {
    					validationErrors.add("ST01 must be 'ST'.");
    				}

    				// Example: Validate ST02 is "837"
    				if (!getField(stelement, 2).equals("837")) {
    					validationErrors.add("ST02 must be '837'.");
    				}

    				// Example: Validate ST03 is "0001"
    				if (!getField(stelement, 3).equals("0001")) {
    					validationErrors.add("ST03 must be '0001'.");
    				}

    				// Example: Validate ST04 is "005010X224A2"
    				if (!getField(stelement, 4).equals("005010X224A2")) {
    					validationErrors.add("ST04 must be '005010X224A2'.");
    				}
    			}
    }
}
