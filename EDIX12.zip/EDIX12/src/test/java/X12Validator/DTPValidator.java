package X12Validator;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class DTPValidator extends X12Utils {

	public void validateDTP(String edi837) {
		// DTP validation logic
		// ...

		List<String> dtpSegments = X12Utils.getAllDTPSegments(edi837);
		// DTP validation logic
		// ...
		System.out.println(dtpSegments);

		for (String dtpSegment : dtpSegments) {
			boolean isValid = validateDTPSegment(dtpSegment);
			System.out.println("Validation Result: " + isValid);

		}

	}

	public boolean validateDTPSegment(String dtpSegment) {
		// Construct a flexible DTP segment pattern

		// Construct a flexible DTP segment pattern
		String segmentPattern = "DTP\\*([^*]+)\\*([^*]+)\\*([^~]+)~";

		// Compile the regular expression pattern
		Pattern pattern = Pattern.compile(segmentPattern);
		Matcher matcher = pattern.matcher(dtpSegment);

		// Check if the pattern matches
		if (matcher.find()) {
			// Extract and print values for debugging
			System.out.println(matcher.groupCount());
			for (int i = 1; i <= matcher.groupCount(); i++) {
				System.out.println("Group " + i + ": " + matcher.group(i));
			}

			// Perform additional validations...

			String qualifier1 = matcher.group(1);
			String formatCode1 = matcher.group(2);
			String dateRange1 = matcher.group(3);

			// Process or print the extracted information
			System.out.println("Qualifier: " + qualifier1);
			System.out.println("Format Code: " + formatCode1);
			System.out.println("Date Range: " + dateRange1);

			// Return the result of validations
			return true; // For now, consider it valid

		} else {
			// Print the entire DTP segment when no match is found
			System.out.println("No match found. DTP Segment: " + dtpSegment);
		}

		return false; // Pattern did not match
	}
}
