package X12Validator;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class REFValidator extends X12Utils {

	public void validateREF(String edi837) {
		// REF validation logic
		// ...

		List<String> refSegments = X12Utils.getAllREFSegments(edi837);
		// REF validation logic
		// ...
		System.out.println(refSegments);

		for (String refSegment : refSegments) {
			boolean isValid = validateREFSegment(refSegment);
			System.out.println("Validation Result: " + isValid);

		}

	}

	public boolean validateREFSegment(String refSegment) {
		
		// Construct a flexible REF segment pattern
	    String segmentPattern = "REF\\*([^*]+)\\*([^~]+)~";

	    // Compile the regular expression pattern
	    Pattern pattern = Pattern.compile(segmentPattern);
	    Matcher matcher = pattern.matcher(refSegment);

	    // Check if the pattern matches
	    if (matcher.find()) {
	        // Extract and print values for debugging
	        for (int i = 1; i <= matcher.groupCount(); i++) {
	            System.out.println("Group " + i + ": " + matcher.group(i));
	        }

	        // Perform additional validations...
	        String referenceQualifier = matcher.group(1);
	        String referenceValue = matcher.group(2);

	        // Example additional validations
	        if ("EI".equals(referenceQualifier) || "D9".equals(referenceQualifier) || referenceQualifier.startsWith("6R")) {
	            System.out.println("Reference qualifier and value are valid.");
	        } else {
	            System.out.println("Reference qualifier or value validation failed.");
	            return false; // Additional validation failed
	        }

	        // Return the result of validations
	        return true; // For now, consider it valid
	    } else {
	        // Print the entire REF segment when no match is found
	        System.out.println("No match found. REF Segment: " + refSegment);
	    }

		return false; // Pattern did not match
	}
}
