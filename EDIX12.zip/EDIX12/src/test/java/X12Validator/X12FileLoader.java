package X12Validator;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.nio.charset.StandardCharsets;

public class X12FileLoader {

    public static String loadX12File(String filePath) throws IOException {
        try {
            StringBuilder stringBuilder = new StringBuilder();
            BufferedReader reader = new BufferedReader(new FileReader(filePath, StandardCharsets.UTF_8));
            String line;

            while ((line = reader.readLine()) != null) {
                stringBuilder.append(line);
                stringBuilder.append(System.lineSeparator());
            }

            reader.close();
            return stringBuilder.toString();
        } catch (IOException e) {
            System.out.println("Error occurred while loading the X12 file: " + e.getMessage());
            throw e; // Rethrow the exception to the caller
        }
    }
}