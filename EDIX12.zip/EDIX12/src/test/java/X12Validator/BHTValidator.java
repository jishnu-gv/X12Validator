package X12Validator;

public class BHTValidator extends X12Utils {

    public void validateBHT(String edi837) {
        // BHT validation logic
        // ...
    	// Perform BHT segment validation
    			// Example: Check BHT segment length, format, values, etc.
    			// If there's an error, add it to validationErrors list
    			String BHTSegment = getSegment("BHT", edi837);

    			System.out.println(BHTSegment);

    			String[] bhtElement = BHTSegment.split("~");

    			// Print the elements
    			for (String bhtelement : bhtElement) {
    				System.out.println(bhtelement);

    				String[] bhtElements = bhtelement.split("\\*");
    				System.out.println("BHT Elements:");
    				for (int i = 0; i < bhtElements.length; i++) {
    					System.out.println("Element " + (i + 1) + ": " + bhtElements[i]);
    				}

    				// Example: Check if BHT segment exists
    				if (bhtelement == null) {
    					validationErrors.add("BHT segment is missing.");
    					return;
    				}

    				// Example: Check BHT segment length
    				if (bhtelement.length() != 45) {
    					validationErrors.add("BHT segment has an invalid length.");
    				}

    				// Example: Validate BHT01 is "BHT"
    				if (!getField(bhtelement, 1).equals("BHT")) {
    					validationErrors.add("BHT01 must be 'BHT'.");
    				}

    				// Example: Validate BHT02 is "0019"
    				if (!getField(bhtelement, 2).equals("0019")) {
    					validationErrors.add("BHT02 must be '0019'.");
    				}

    				// Example: Validate BHT03 is "00"
    				if (!getField(bhtelement, 3).equals("00")) {
    					validationErrors.add("BHT03 must be '00'.");
    				}

    				String dateStr = getField(bhtelement, 5);
    				String timeStr = getField(bhtelement, 6);

    				// Validate date and time
    				boolean isDateValid = isValidDateY(dateStr);
    				boolean isTimeValid = isValidTimeY(timeStr);

    				System.out.println("Is Date Valid for BHT? " + isDateValid);
    				System.out.println("Is Time Valid for BHT? " + isTimeValid);

    				// Example: Validate BHT07 is "CH"
    				if (!getField(bhtelement, 7).equals("CH")) {
    					validationErrors.add("BHT07 must be 'CH'.");
    				}
    			}

    }
}

