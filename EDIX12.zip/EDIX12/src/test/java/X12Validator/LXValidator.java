package X12Validator;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LXValidator extends X12Utils {

	public void validateLX(String edi837) {
		List<String> lxSegments = X12Utils.getAllLXSegments(edi837);
		// LX validation logic
		// ...
		System.out.println(lxSegments);

		for (String lxSegment : lxSegments) {
			boolean isValid = validateLXSegment(lxSegment);
			System.out.println("Validation Result: " + isValid);

		}
	}

	public boolean validateLXSegment(String lxSegment) {
		// Construct a flexible LX segment pattern
		

		String lxPattern = "LX\\*\\d+~";

        // Compile the regular expression pattern
        Pattern pattern = Pattern.compile(lxPattern);
        Matcher matcher = pattern.matcher(lxSegment);

        // Check if the pattern matches
        if (matcher.matches()) {
            // Perform additional validations if needed...
            return true; // For now, consider it valid
        } else {
            System.out.println("No match found. LX Segment: " + lxSegment);
            return false; // Pattern did not match
        }
    }

	// Other helper methods and fields...
}
