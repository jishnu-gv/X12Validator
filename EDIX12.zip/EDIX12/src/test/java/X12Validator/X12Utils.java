package X12Validator;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class X12Utils {
	
	public List<String> validationErrors;

    public X12Utils() {
        this.validationErrors = new ArrayList<>();
    }
    
    public void generateValidationReport() {
        if (!validationErrors.isEmpty()) {
            // Create a report file
            String reportFileName = "validation_report_" + X12Utils.getFormattedDate() + ".txt";
            X12Utils.writeToFile(validationErrors, reportFileName);
            System.out.println("Validation report generated successfully.");
        } else {
            System.out.println("No validation errors found.");
        }
    }
    
    public boolean isValidTime(String timeStr) {

		final String TIME_FORMAT = "HHmm";

		// TODO Auto-generated method stub

		SimpleDateFormat timeFormat = new SimpleDateFormat(TIME_FORMAT);
		timeFormat.setLenient(false); // Disable lenient parsing

		try {
			Date time = timeFormat.parse(timeStr);
			// If parsing succeeds, the time is valid
			return true;
		} catch (ParseException e) {
			// Parsing failed, the time is invalid
			return false;
		}

	}
	
	public boolean isValidTimeY(String timeStr) {

		final String TIME_FORMAT = "HHmmss";

		// TODO Auto-generated method stub

		SimpleDateFormat timeFormat = new SimpleDateFormat(TIME_FORMAT);
		timeFormat.setLenient(false); // Disable lenient parsing

		try {
			Date time = timeFormat.parse(timeStr);
			// If parsing succeeds, the time is valid
			return true;
		} catch (ParseException e) {
			// Parsing failed, the time is invalid
			return false;
		}

	}

	public boolean isValidDate(String dateStr) {

		final String DATE_FORMAT = "yyMMdd";
		// TODO Auto-generated method stub

		SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
		dateFormat.setLenient(false); // Disable lenient parsing

		try {
			Date date = dateFormat.parse(dateStr);
			// If parsing succeeds, the date is valid
			return true;
		} catch (ParseException e) {
			// Parsing failed, the date is invalid
			return false;
		}
	}

	public boolean isValidDateY(String dateStr) {

		final String DATE_FORMAT = "yyyyMMdd";
		// TODO Auto-generated method stub

		SimpleDateFormat dateFormat = new SimpleDateFormat(DATE_FORMAT);
		dateFormat.setLenient(false); // Disable lenient parsing

		try {
			Date date = dateFormat.parse(dateStr);
			// If parsing succeeds, the date is valid
			return true;
		} catch (ParseException e) {
			// Parsing failed, the date is invalid
			return false;
		}
	}

    public static String getFormattedDate() {
        Date now = new Date();
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMdd_HHmmss");
        return dateFormat.format(now);
    }
    
    public static String getSegment(String segmentIdentifier, String edi837) {
		String segmentPattern = segmentIdentifier + "[^~]*?(~|$)";
		java.util.regex.Pattern pattern = java.util.regex.Pattern.compile(segmentPattern,
				java.util.regex.Pattern.DOTALL);
		java.util.regex.Matcher matcher = pattern.matcher(edi837);
		return matcher.find() ? matcher.group() : null;
	}

	// Helper method to extract a specific field from a segment
	public String getField(String segment, int fieldNumber) {
		String[] fields = segment.split("\\*");
		return fieldNumber <= fields.length ? fields[fieldNumber - 1] : "";
	}

    public static List<String> getAllNM1Segments(String ediContent) {
        // NM1 segment retrieval logic
    	
    	List<String> nm1Segments = new ArrayList<>();

        // Construct the NM1 segment pattern dynamically
        String segmentIdentifier = "NM1";
        String segmentPattern = segmentIdentifier + "[^~]*?(~|$)";

        // Compile the regular expression pattern
        Pattern pattern = Pattern.compile(segmentPattern, Pattern.DOTALL);
        Matcher matcher = pattern.matcher(ediContent);

        // Find all matching NM1 segments
        while (matcher.find()) {
            // Add the matched NM1 segment to the list
            nm1Segments.add(matcher.group());
        }

        return nm1Segments;
    }
    
    public static List<String> getAllHLSegments(String ediContent) {
        // HL segment retrieval logic
    	
    	List<String> hlSegments = new ArrayList<>();

        // Construct the HL segment pattern dynamically
        String segmentIdentifier = "HL";
        String segmentPattern = segmentIdentifier + "[^~]*?(~|$)";

        // Compile the regular expression pattern
        Pattern pattern = Pattern.compile(segmentPattern, Pattern.DOTALL);
        Matcher matcher = pattern.matcher(ediContent);

        // Find all matching HL segments
        while (matcher.find()) {
            // Add the matched HL segment to the list
            hlSegments.add(matcher.group());
        }

        return hlSegments;
    }
    
    public static List<String> getAllN3Segments(String ediContent) {
        // N3 segment retrieval logic
    	
    	List<String> n3Segments = new ArrayList<>();

        // Construct the N3 segment pattern dynamically
        String segmentIdentifier = "N3";
        String segmentPattern = segmentIdentifier + "[^~]*?(~|$)";

        // Compile the regular expression pattern
        Pattern pattern = Pattern.compile(segmentPattern, Pattern.DOTALL);
        Matcher matcher = pattern.matcher(ediContent);

        // Find all matching N3 segments
        while (matcher.find()) {
            // Add the matched N3 segment to the list
            n3Segments.add(matcher.group());
        }

        return n3Segments;
    }
    
    public static List<String> getAllN4Segments(String ediContent) {
        // N4 segment retrieval logic
    	
    	List<String> n4Segments = new ArrayList<>();

        // Construct the N4 segment pattern dynamically
        String segmentIdentifier = "N4";
        String segmentPattern = segmentIdentifier + "[^~]*?(~|$)";

        // Compile the regular expression pattern
        Pattern pattern = Pattern.compile(segmentPattern, Pattern.DOTALL);
        Matcher matcher = pattern.matcher(ediContent);

        // Find all matching N4 segments
        while (matcher.find()) {
            // Add the matched N4 segment to the list
            n4Segments.add(matcher.group());
        }

        return n4Segments;
    }
    
    public static List<String> getAllREFSegments(String ediContent) {
        // REF segment retrieval logic
    	
    	List<String> refSegments = new ArrayList<>();

        // Construct the REF segment pattern dynamically
        String segmentIdentifier = "REF";
        String segmentPattern = segmentIdentifier + "[^~]*?(~|$)";

        // Compile the regular expression pattern
        Pattern pattern = Pattern.compile(segmentPattern, Pattern.DOTALL);
        Matcher matcher = pattern.matcher(ediContent);

        // Find all matching REF segments
        while (matcher.find()) {
            // Add the matched REF segment to the list
            refSegments.add(matcher.group());
        }

        return refSegments;
    }
    
    public static List<String> getAllDTPSegments(String ediContent) {
        // DTP segment retrieval logic
    	
    	List<String> dtpSegments = new ArrayList<>();

        // Construct the DTP segment pattern dynamically
        String segmentIdentifier = "DTP";
        String segmentPattern = segmentIdentifier + "[^~]*?(~|$)";

        // Compile the regular expression pattern
        Pattern pattern = Pattern.compile(segmentPattern, Pattern.DOTALL);
        Matcher matcher = pattern.matcher(ediContent);

        // Find all matching DTP segments
        while (matcher.find()) {
            // Add the matched DTP segment to the list
            dtpSegments.add(matcher.group());
        }

        return dtpSegments;
    }
    
    public static List<String> getAllHCPSegments(String ediContent) {
        // HCP segment retrieval logic
    	
    	List<String> hcpSegments = new ArrayList<>();

        // Construct the HCP segment pattern dynamically
        String segmentIdentifier = "HCP";
        String segmentPattern = segmentIdentifier + "[^~]*?(~|$)";

        // Compile the regular expression pattern
        Pattern pattern = Pattern.compile(segmentPattern, Pattern.DOTALL);
        Matcher matcher = pattern.matcher(ediContent);

        // Find all matching HCP segments
        while (matcher.find()) {
            // Add the matched HCP segment to the list
            hcpSegments.add(matcher.group());
        }

        return hcpSegments;
    }
    
    public static List<String> getAllLXSegments(String ediContent) {
        // LX segment retrieval logic
    	
    	List<String> lxSegments = new ArrayList<>();

        // Construct the LX segment pattern dynamically
        String segmentIdentifier = "LX";
        String segmentPattern = segmentIdentifier + "[^~]*?(~|$)";

        // Compile the regular expression pattern
        Pattern pattern = Pattern.compile(segmentPattern, Pattern.DOTALL);
        Matcher matcher = pattern.matcher(ediContent);

        // Find all matching LX segments
        while (matcher.find()) {
            // Add the matched LX segment to the list
            lxSegments.add(matcher.group());
        }

        return lxSegments;
    }
    
    public static List<String> getAllSV3Segments(String ediContent) {
        // SV3 segment retrieval logic
    	
    	List<String> sv3Segments = new ArrayList<>();

        // Construct the SV3 segment pattern dynamically
        String segmentIdentifier = "SV3";
        String segmentPattern = segmentIdentifier + "[^~]*?(~|$)";

        // Compile the regular expression pattern
        Pattern pattern = Pattern.compile(segmentPattern, Pattern.DOTALL);
        Matcher matcher = pattern.matcher(ediContent);

        // Find all matching SV3 segments
        while (matcher.find()) {
            // Add the matched SV3 segment to the list
            sv3Segments.add(matcher.group());
        }

        return sv3Segments;
    }
    
    public static List<String> getAllTOOSegments(String ediContent) {
        // TOO segment retrieval logic
    	
    	List<String> tooSegments = new ArrayList<>();

        // Construct the TOO segment pattern dynamically
        String segmentIdentifier = "TOO";
        String segmentPattern = segmentIdentifier + "[^~]*?(~|$)";

        // Compile the regular expression pattern
        Pattern pattern = Pattern.compile(segmentPattern, Pattern.DOTALL);
        Matcher matcher = pattern.matcher(ediContent);

        // Find all matching TOO segments
        while (matcher.find()) {
            // Add the matched TOO segment to the list
            tooSegments.add(matcher.group());
        }

        return tooSegments;
    }
    

    public static void writeToFile(List<String> content, String fileName) {
        try (FileWriter writer = new FileWriter(fileName)) {
            for (String line : content) {
                writer.write(line + "\n");
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
