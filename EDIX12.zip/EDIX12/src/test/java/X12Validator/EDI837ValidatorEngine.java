package X12Validator;

import java.util.HashSet;
import java.util.Set;


public class EDI837ValidatorEngine extends X12Utils {

	// Define the pattern for identifying segment names
	private Set<String> processedSegments = new HashSet<>();

	public void validateEDI837(String edi837) {
		// Perform segment validations and add errors to validationErrors list
		// Example: Validate ISA, GS, ST, NM1, NM3, and other segments

		// Split the EDI string into segments
		String[] segments = edi837.split("~");

		// Process each segment
		
		for (String segment : segments) {
			
			System.out.println("segment--->" + segment);
			callSegmentMethod(segment.trim(), edi837);
		}

		// Report generation
		generateValidationReport();

	}

	private void callSegmentMethod(String segment, String edi837) {

		// Extract segment name
		String segmentName = segment.split("\\*")[0];
		System.out.println("segmentName -->" + segmentName);
		
		// Check if the segment has been processed already
		if (!processedSegments.contains(segmentName)) {
			// Process each segment based on its name

			switch (segmentName) {
			case "ISA":
				new ISAValidator().validateISA(edi837);
				break;
			case "GS":
				new GSValidator().validateGS(edi837);
				break;
			case "ST":
				new STValidator().validateST(edi837);
				break;
			case "BHT":
				new BHTValidator().validateBHT(edi837);
				break;
			case "NM1":
				new NM1Validator().validateNM1(edi837);
				break;
			case "PER":
				new PERValidator().validatePER(edi837);
				break;
			case "HL":
				new HLValidator().validateHL(edi837);
				break;
			case "N3":
				new N3Validator().validateN3(edi837);
				break;
			case "N4":
				new N4Validator().validateN4(edi837);
				break;
			case "REF":
				new REFValidator().validateREF(edi837);
				break;
			case "SBR":
				new SBRValidator().validateSBR(edi837);
				break;
			case "DMG":
				new DMGValidator().validateDMG(edi837);
				break;
			case "CLM":
				new CLMValidator().validateCLM(edi837);
				break;
			case "DTP":
				new DTPValidator().validateDTP(edi837);
				break;
			case "HCP":
				new HCPValidator().validateHCP(edi837);
				break;
			case "PRV":
				new PRVValidator().validatePRV(edi837);
				break;
			case "LX":
				new LXValidator().validateLX(edi837);
				break;
			case "SV3":
				new SV3Validator().validateSV3(edi837);
				break;
			case "TOO":
				new TOOValidator().validateTOO(edi837);
				break;
			case "SE":
				new SEValidator().validateSE(edi837);
				break;
			case "GE":
				new GEValidator().validateGE(edi837);
				break;
			case "IEA":
				new IEAValidator().validateIEA(edi837);
				break;
			// Add more cases for other segment names and their corresponding validators
			default:
				System.out.println("No validator found for segment: " + segmentName);
			}

			// Mark the segment as processed
			processedSegments.add(segmentName);
		} else {
			// Segment has already been processed
			System.out.println("Segment " + segmentName + " has already been processed.");
		}

		// Add validations for other segments

	}
}
