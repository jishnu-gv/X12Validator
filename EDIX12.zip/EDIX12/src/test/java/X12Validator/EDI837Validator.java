package X12Validator;

import org.testng.annotations.Test;
import java.io.IOException;

public class EDI837Validator {

    private String filePath = "D:\\Ramesh-Personal\\Selenium\\Files\\JV_202303220943Msingleclaimfix.x12";
    private String edi837;

    @Test
    
    public void validateEDI837Test() {
        try {
            edi837 = X12FileLoader.loadX12File(filePath);
        } catch (IOException e) {
            e.printStackTrace();
        }

        System.out.println(edi837);

        EDI837ValidatorEngine validatorEngine = new EDI837ValidatorEngine();
        validatorEngine.validateEDI837(edi837);
    }
}

