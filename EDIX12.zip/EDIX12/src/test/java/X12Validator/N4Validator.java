package X12Validator;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class N4Validator extends X12Utils {

	public void validateN4(String edi837) {
		// N4 validation logic
		// ...

		List<String> n4Segments = X12Utils.getAllN4Segments(edi837);
		// N4 validation logic
		// ...
		System.out.println(n4Segments);

		for (String n4Segment : n4Segments) {
			boolean isValid = validateN4Segment(n4Segment);
			System.out.println("Validation Result: " + isValid);

		}

	}

	public boolean validateN4Segment(String n4Segment) {
		// Construct a flexible N4 segment pattern
		
		 String segmentPattern = "N4\\*([^*]+)\\*([^*]+)\\*([^~]+)~";
		 
		// Compile the regular expression pattern
		Pattern pattern = Pattern.compile(segmentPattern);
		Matcher matcher = pattern.matcher(n4Segment);

		// Check if the pattern matches
		if (matcher.find()) {
			// Extract and print values for debugging
			for (int i = 1; i <= matcher.groupCount(); i++) {
				System.out.println("Group " + i + ": " + matcher.group(i));
			}

			// Perform validations...
			
			 String city = matcher.group(1);
		        String state = matcher.group(2);
		        String zipCode = matcher.group(3);

		        // Example additional validations
		        if (city.length() > 0 && state.length() == 2 && zipCode.length() == 5) {
		            System.out.println("City, state, and ZIP code are valid.");
		        } else {
		            System.out.println("City, state, or ZIP code validation failed.");
		            return false; // Additional validation failed
		        }
			

			// Return the result of validations
			return true; // For now, consider it valid
		} else {
			// Print the entire N4 segment when no match is found
			System.out.println("No match found. N4 Segment: " + n4Segment);
		}

		return false; // Pattern did not match
	}
}
